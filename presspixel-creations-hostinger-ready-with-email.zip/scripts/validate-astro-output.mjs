import { access, readFile, readdir } from 'node:fs/promises';
import { extname, join, resolve } from 'node:path';

const root = resolve('dist/client');
const redirects = await readFile(join(root, '_redirects'), 'utf8').catch(() => '');
const redirectPaths = new Set(redirects.split('\n').map(line => line.trim().split(/\s+/)[0]).filter(Boolean));
const htmlFiles = [];

async function walk(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) await walk(path);
    else if (extname(entry.name) === '.html') htmlFiles.push(path);
  }
}
await walk(root);

const errors = [];
for (const file of htmlFiles) {
  const html = await readFile(file, 'utf8');
  if (!/<title>[^<]+<\/title>/.test(html)) errors.push(`${file}: missing title`);
  if (!/<meta name="description" content="[^"]+"/.test(html)) errors.push(`${file}: missing description`);
  if (!/<link rel="canonical" href="https:\/\/presspixelcreations\.com\//.test(html)) errors.push(`${file}: missing canonical`);
  if (!/<h1[ >]/.test(html)) errors.push(`${file}: missing h1`);

  for (const match of html.matchAll(/href="([^"]+)"/g)) {
    const href = match[1];
    if (!href.startsWith('/') || href.startsWith('//')) continue;
    const pathname = href.split(/[?#]/)[0] || '/';
    if (redirectPaths.has(pathname)) continue;
    const target = pathname === '/' ? join(root, 'index.html') : join(root, pathname, 'index.html');
    const direct = join(root, pathname);
    try { await access(target); }
    catch { try { await access(direct); } catch { errors.push(`${file}: broken internal link ${href}`); } }
  }
}

await access(resolve('dist/server/entry.mjs')).catch(() => errors.push('missing Node server entrypoint'));
const serverEntry = await readFile(resolve('dist/server/entry.mjs'), 'utf8').catch(() => '');
if (!serverEntry) errors.push('Node server entrypoint is empty');

const serverChunks = await readdir(resolve('dist/server/chunks')).catch(() => []);
let foundEnquiryEndpoint = false;
for (const chunk of serverChunks) {
  if (!chunk.endsWith('.mjs') && !chunk.endsWith('.js')) continue;
  const content = await readFile(resolve('dist/server/chunks', chunk), 'utf8').catch(() => '');
  if (content.includes('/api/enquiries') || content.includes('Enquiry save failed')) {
    foundEnquiryEndpoint = true;
    break;
  }
}
if (!foundEnquiryEndpoint && !serverEntry.includes('/api/enquiries')) {
  errors.push('enquiry endpoint missing from Node server bundle');
}

if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}
console.log(`Validated ${htmlFiles.length} prerendered HTML pages, internal links, Node server output, and enquiry endpoint.`);
