# PressPixel Creations — Astro (Hostinger edition)

A standalone Astro website for PressPixel Creations. The site uses native Astro components and browser JavaScript; React and Next.js are not part of this project.

## Requirements

- Node.js 22.13 or newer
- npm
- MySQL 8 / compatible Hostinger MySQL database

## Run locally

```sh
npm install
npm run dev
```

Create a local `.env` from `.env.example` and add working MySQL credentials before testing enquiry submissions.

## Production build

```sh
npm run build
npm start
```

Astro writes static browser assets to `dist/client/` and the Hostinger-compatible standalone Node server to `dist/server/`.

## Hosting

This edition uses Astro's official Node adapter in standalone mode. The `/api/enquiries` endpoint writes enquiry submissions to MySQL using a small connection pool, then sends SMTP notifications to `ashrafkhanak15@gmail.com` and `support@presspixelcreations.com`. Run `db/schema.sql` once on the Hostinger database, then configure the database and SMTP environment variables listed in `.env.example`.

The public pages, metadata, canonical URLs, sitemap, GSAP animation, Lenis scrolling, and enquiry form UI are otherwise unchanged from the final Astro redevelopment.

See `HOSTINGER-SETUP.md` for the deployment checklist.

## Main folders

- `src/pages/` — routes and page templates
- `src/components/` — native Astro components
- `src/styles/theme.css` — global colours, fonts, spacing, radii, shadows, and motion tokens
- `src/styles/global.css` — layouts and component styling built from the theme tokens
- `public/` — images, icons, and static files
- `lib/` — site content and enquiry validation
- `db/` — Hostinger/MySQL enquiry storage and schema

To change the brand system later, start with `src/styles/theme.css`.
