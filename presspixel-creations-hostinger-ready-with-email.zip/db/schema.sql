CREATE TABLE IF NOT EXISTS enquiries (
  id VARCHAR(128) PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(254) NOT NULL,
  company VARCHAR(200) NOT NULL DEFAULT '',
  website VARCHAR(500) NOT NULL DEFAULT '',
  services JSON NOT NULL,
  message TEXT NOT NULL,
  consent VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  notification_sent_at TIMESTAMP NULL DEFAULT NULL,
  notification_error VARCHAR(500) NULL DEFAULT NULL,
  INDEX idx_enquiries_email_created_at (email, created_at)
);
