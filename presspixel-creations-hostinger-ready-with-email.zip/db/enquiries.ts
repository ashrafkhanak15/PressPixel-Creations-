import type { RowDataPacket } from 'mysql2/promise';
import { getDb } from './index';

type EnquiryInput = {
  id: string;
  name: string;
  email: string;
  company: string;
  website: string;
  services: string[];
  message: string;
};

interface ExistingRow extends RowDataPacket {
  id: string;
}

interface CountRow extends RowDataPacket {
  total: number;
}

export async function saveEnquiry(data: EnquiryInput) {
  const db = getDb();

  const [existing] = await db.execute<ExistingRow[]>(
    'SELECT id FROM enquiries WHERE id = ? LIMIT 1',
    [data.id],
  );
  if (existing.length > 0) {
    return { saved: true as const, duplicate: true as const, limited: false as const };
  }

  const [recent] = await db.execute<CountRow[]>(
    `SELECT COUNT(*) AS total
       FROM enquiries
      WHERE email = ?
        AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 1 HOUR)`,
    [data.email],
  );

  if ((recent[0]?.total ?? 0) >= 3) {
    return { saved: false as const, duplicate: false as const, limited: true as const };
  }

  await db.execute(
    `INSERT INTO enquiries
      (id, name, email, company, website, services, message, consent)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE id = VALUES(id)`,
    [
      data.id,
      data.name,
      data.email,
      data.company,
      data.website,
      JSON.stringify(data.services),
      data.message,
      'Agreed to privacy policy and contact about enquiry',
    ],
  );

  return { saved: true as const, duplicate: false as const, limited: false as const };
}

export async function markEnquiryNotification(id: string, sent: boolean, error?: string) {
  const db = getDb();
  await db.execute(
    `UPDATE enquiries
        SET notification_sent_at = ?,
            notification_error = ?
      WHERE id = ?`,
    [sent ? new Date() : null, sent ? null : (error || 'Unknown notification error').slice(0, 500), id],
  );
}
