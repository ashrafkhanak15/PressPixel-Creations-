# PressPixel Creations — Hostinger deployment

This build has been converted from Cloudflare Workers + D1 to Astro's Node adapter + MySQL for Hostinger. Enquiry submissions are stored in MySQL first and then notification emails are sent to both owner inboxes.

## What was changed

- Cloudflare adapter replaced with `@astrojs/node` in standalone mode.
- Cloudflare D1 enquiry storage replaced with `mysql2` connection pooling.
- Existing `/api/enquiries` validation, origin protection, honeypot, idempotency, and per-email rate limiting are preserved.
- SMTP notifications are sent after a successful database insert.
- Notification delivery status/error is recorded on the enquiry row.
- Retried requests with the same enquiry ID do not send duplicate notification emails.
- The frontend form and website pages are unchanged.

## 1. Hostinger database

Create a MySQL database in hPanel and run `db/schema.sql` once (phpMyAdmin is fine).

Then add these environment variables to the Hostinger web app:

- `DB_HOST`
- `DB_PORT` (normally `3306`)
- `DB_NAME`
- `DB_USER`
- `DB_PASSWORD`

Never put the real database password into the repository or `.env.example`.

## 2. Email notification SMTP

Configure the SMTP account that should SEND the website alerts. The notification RECIPIENTS are:

- `ashrafkhanak15@gmail.com`
- `support@presspixelcreations.com`

Add these environment variables:

- `SMTP_HOST`
- `SMTP_PORT` (commonly `465` for implicit TLS or `587` for STARTTLS)
- `SMTP_SECURE` (`true` for port 465; normally `false` for 587)
- `SMTP_USER`
- `SMTP_PASS`
- `ENQUIRY_FROM_EMAIL` (normally the same mailbox as `SMTP_USER`)
- `ENQUIRY_NOTIFY_TO=ashrafkhanak15@gmail.com,support@presspixelcreations.com`

Use the SMTP settings supplied by the provider that hosts the sending mailbox. If that mailbox uses two-factor authentication, use the provider's app password or SMTP credential instead of your normal account password where required.

The customer email is set as `Reply-To`, so clicking Reply on a notification starts a reply to the person who submitted the form.

## 3. Build and start

Node.js: 22+

Build command:

```bash
npm run build
```

Start command:

```bash
npm start
```

The standalone Node server entry is `dist/server/entry.mjs`.

## 4. Enquiry smoke test after deployment

1. Open the live `/contact` page.
2. Submit a real test enquiry using an email address you control.
3. Confirm the browser shows the success state.
4. Open phpMyAdmin and verify the row exists in the `enquiries` table.
5. Confirm `notification_sent_at` is populated and `notification_error` is empty.
6. Confirm the notification arrives at BOTH `ashrafkhanak15@gmail.com` and `support@presspixelcreations.com`.
7. Hit Reply on the notification and confirm the recipient is the test customer's email address.
8. In a controlled test only, submit more than three distinct enquiries with the same email within an hour; the fourth should return HTTP 429.

Do not consider the migration complete until the database row and both notification inboxes have been verified.
