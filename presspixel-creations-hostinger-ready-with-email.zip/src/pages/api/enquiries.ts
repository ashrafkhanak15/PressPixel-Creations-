import type { APIRoute } from 'astro';
import { enquirySchema } from '../../../lib/enquiry';
import { sendEnquiryNotification } from '../../../lib/enquiry-notifications';
import { markEnquiryNotification, saveEnquiry } from '../../../db/enquiries';

export const prerender = false;

export const POST: APIRoute = async ({ request }) => {
  const origin = request.headers.get('origin');
  if (origin && origin !== new URL(request.url).origin) return Response.json({ error: 'Please submit the form from this website.' }, { status: 403 });
  if (!request.headers.get('content-type')?.includes('application/json')) return Response.json({ error: 'Please send a valid enquiry.' }, { status: 415 });

  try {
    const body = await request.text();
    if (body.length > 20000) return Response.json({ error: 'Your message is too long.' }, { status: 413 });

    let json: unknown;
    try { json = JSON.parse(body); } catch { return Response.json({ error: 'Please send a valid enquiry.' }, { status: 400 }); }

    const result = enquirySchema.safeParse(json);
    if (!result.success) return Response.json({ error: result.error.issues[0].message }, { status: 400 });
    if (result.data.companyFax) return Response.json({ received: true });

    const outcome = await saveEnquiry(result.data);
    if (outcome.limited) return Response.json({ error: 'You’ve already sent several enquiries. Please email support@presspixelcreations.com if you need to add anything.' }, { status: 429 });

    // Do not notify again if the browser retries the same enquiry ID.
    if (!outcome.duplicate) {
      const notification = await sendEnquiryNotification(result.data);

      try {
        await markEnquiryNotification(result.data.id, notification.sent, notification.sent ? undefined : notification.error);
      } catch (statusError) {
        console.error('Could not record enquiry notification status:', statusError instanceof Error ? statusError.message : 'Unknown error');
      }

      if (!notification.sent) {
        console.error(`Enquiry ${result.data.id} was saved, but email notification failed: ${notification.error}`);
      }
    }

    return Response.json({ received: true }, { status: 201 });
  } catch (error) {
    console.error('Enquiry save failed:', error instanceof Error ? error.message : 'Unknown error');
    return Response.json({ error: 'We couldn’t save your enquiry. Your details are still here; please try again or email support@presspixelcreations.com.' }, { status: 503 });
  }
};
